package terminalloket;
import java.util.Scanner;
import model.*;
import service.LayananEksklusif;
/**
 *
 * @author Mast
 */
public class TerminalLoket {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        Tiket[] daftarTiket = new Tiket[100];
        int jumlah = 0;
        
        boolean jalan = true;
        String lanjut = "y";
        
        while(jalan && lanjut.equalsIgnoreCase("y")){
            
            System.out.println("\n=== Menu Tiket ===");
            System.out.println("1. Ekonomi");
            System.out.println("2. Eksekutif");
            System.out.println("3. Luxury");
            System.out.println("0. Keluar");
            System.out.print("Pilih kelas tiket: ");
            int pilihan = input.nextInt();
            input.nextLine();
            
            if(pilihan == 0){
                jalan = false;
                break;
            }
            
            try{
                System.out.print("Kode Tiket : ");
                String kode = input.nextLine();
                
                System.out.print("Tanggal : ");
                String tanggal = input.nextLine();
                
                System.out.print("Waktu : ");
                String waktu = input.nextLine();
                
                System.out.print("Tujuan : ");
                String tujuan = input.nextLine();
                
                System.out.print("Harga Dasar : ");
                Double harga = input.nextDouble();
                input.nextLine();
                
                Jadwal jadwal = new Jadwal(tanggal, waktu, tujuan);
                
                Tiket tiket = null;
                
                switch(pilihan) {
                    case 1:
                        tiket = new TiketEkonomi(kode, jadwal, harga);
                        break;
                    case 2:
                        tiket = new TiketEksekutif(kode, jadwal, harga);
                        break;
                    case 3:
                        tiket = new TiketLuxury(kode, jadwal, harga);
                        break;
                }
                
                daftarTiket[jumlah] = tiket;
                jumlah++;
                
                System.out.println("Tiket Berhasil Ditambahkan!!");
                
                System.out.print("Cetak tiket lain? (y/n): ");
                lanjut = input.nextLine();
                
            }catch(DataTiketInvalidException e){
                
                System.out.println("[ERROR] " + e.getMessage());
                
            }catch(Exception e){
                System.out.println("[ERROR] Input harga harus berupa angka! ");
                input.nextLine();
                
            }
        }
        
        System.out.println("\n=== Rekap Tiket ===");
        
        for(int i=0; i<jumlah; i++){
            
            System.out.println("Kode : " + daftarTiket[i].getKodeTiket());
            System.out.println("Jadwal : " + daftarTiket[i].getJadwal().getInfoJadwal());
            System.out.println("Tujuan : " + daftarTiket[i].getJadwal().getTujuan());
            System.out.println("Total Harga : " + daftarTiket[i].hitungHarga());
            if(daftarTiket[i] instanceof LayananEksklusif){
                LayananEksklusif layanan = (LayananEksklusif) daftarTiket[i];
                System.out.println("Fasilitas : " + layanan.getFasilitasTambahan());
            }
            System.out.println("---------------------");
        }
    }
    
}
