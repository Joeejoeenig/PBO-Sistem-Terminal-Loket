package model;
import service.LayananEksklusif;
/**
 *
 * @author Mast
 */
public class TiketEksekutif extends Tiket implements LayananEksklusif {
    
    public TiketEksekutif(String kode, Jadwal jadwal, double hargaDasar)
        throws DataTiketInvalidException {
        
        super(kode, jadwal, hargaDasar);
    }
    
    @Override
    public double hitungHarga(){
        return getHargaDasar() + 50000;
    }
    
    @Override
    public String getFasilitasTambahan(){
        return "Makan Siang";
    }
        
    
}
