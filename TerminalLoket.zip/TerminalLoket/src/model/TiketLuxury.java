package model;
import service.LayananEksklusif;
/**
 *
 * @author Mast
 */
public class TiketLuxury extends Tiket implements LayananEksklusif {
    
    public TiketLuxury(String kode, Jadwal jadwal, double hargaDasar)
        throws DataTiketInvalidException {
        
        super(kode, jadwal, hargaDasar);
    }
    
    @Override
    public double hitungHarga(){
        return getHargaDasar() + 150000;
    }
    
    @Override
    public String getFasilitasTambahan(){
        return "Makan Siang dan Kursi Plenger";
    }
}
