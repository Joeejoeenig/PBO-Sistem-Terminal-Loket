package model;
/**
 *
 * @author Mast
 */
public class Jadwal {
    private String tanggal;
    private String waktu;
    private String tujuan;
    
    public Jadwal(String tanggal, String waktu, String tujuan){
        this.tanggal = tanggal;
        this.waktu = waktu;
        this.tujuan = tujuan;
}

    public String getInfoJadwal(){
        //return tanggal + " | " + waktu + " | " + tujuan;
        return tanggal + " " + waktu;
    }
    
    public String getTujuan(){
        return tujuan;
    }
}