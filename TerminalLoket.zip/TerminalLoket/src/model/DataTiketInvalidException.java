package model;

/**
 *
 * @author Mast
 */
public class DataTiketInvalidException extends Exception {
    
    public DataTiketInvalidException(String pesan){
        super(pesan);
    }
}
