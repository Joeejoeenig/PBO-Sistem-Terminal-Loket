package model;

/**
 *
 * @author Mast
 */
public class TiketEkonomi extends Tiket {
    public TiketEkonomi(String kode, Jadwal jadwal, double hargaDasar)
        throws DataTiketInvalidException {
        
        super(kode, jadwal, hargaDasar);
    } 
    
    @Override
    public double hitungHarga(){
        return getHargaDasar();
    }
}
