package service;

/**
 *
 * @author Mast
 */
public interface LayananEksklusif {
    
    String getFasilitasTambahan();
}
